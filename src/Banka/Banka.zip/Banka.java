package Banka;

public abstract class Banka {

	public static String bankaAdi;
	public static String bankaAdresi;
	
	public abstract void bilgiGetir();
	
	
}
