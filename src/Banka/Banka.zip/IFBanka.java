package Banka;

public interface IFBanka {

	void ekle();
	void sil();
	void guncelle();
	void bilgiGetir();
	void hepsiniGetir();
}
